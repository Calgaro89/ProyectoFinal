package veterinaria;

public class Veterinaria {

    public static void main(String[] args) {
//        Menu nuevo = new Menu();
//        nuevo.setVisible(true);
//        ClienteData clienteData = new ClienteData();
//        Cliente cliente2;
//        Cliente cliente1 = new Cliente(10,25145267, "Bocalon", "Ernesto", "15 y 93", 2214811399L, "Perez Bruno Mariana", true);
//        System.out.println(cliente1);
//        clienteData.guardarCliente(cliente1);
////        
//          cliente2 = clienteData.buscarCliente(25145267);
//          
//          System.out.println("Cliente1: " + cliente1);
//          System.out.println("Cliente2: " + cliente2);
//          cliente1.setTelefono(11111111L);
//        clienteData.modificarCliente(cliente1);
        
//        clienteData.borrarCliente(1111111);
    }
    
}
